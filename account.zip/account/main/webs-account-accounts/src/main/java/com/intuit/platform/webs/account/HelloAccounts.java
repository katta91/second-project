package com.intuit.platform.webs.account;

public class HelloAccounts {
    public static void main(String[] args) {
        System.out.println("Hello Account-Accounts!"); //Display the string.
    }
}