package com.intuit.platform.webs.account;

public class TestHelloAccounts {
    public static void main(String[] args) {
        System.out.println("TestHelloAccounts!"); //Display the string.
    }
}