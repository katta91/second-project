package com.intuit.platform.webs.account;

public class HelloAccountAccountsId {
    public static void main(String[] args) {
        System.out.println("Hello HelloAccountAccountsId !"); //Display the string.
    }
}