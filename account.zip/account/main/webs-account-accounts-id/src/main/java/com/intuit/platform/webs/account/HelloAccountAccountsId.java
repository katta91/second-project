package com.intuit.platform.webs.account;

public class HelloAccountAccountsId {
    public static void main(String[] args) {
        System.out.println("Hello Account Accounts Id!"); //Display the string.
    }
}